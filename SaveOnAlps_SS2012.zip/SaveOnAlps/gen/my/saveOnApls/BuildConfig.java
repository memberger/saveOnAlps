/** Automatically generated file. DO NOT MODIFY */
package my.saveOnApls;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}